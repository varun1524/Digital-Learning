package com.example.varun.matchcolor;

/**
 * Created by Dell on 14-03-2015.
 */
public class Color1
{
    int color;
    int img;
    Color1(int c1)

    {
        this.color=c1;
        // this.img=img;

    }

    public int getColor()
    {
        return color;
    }




}